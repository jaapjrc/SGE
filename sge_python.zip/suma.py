﻿def main():
    total = 0
    for n in range(3):
        numero = int(input("Dime un número "))
        total += numero
    
    print(total)

if __name__ == "__main__":
    main()