def main():
    classmates = []
    for n in range(3):
        classmates.append(input("Dime un nombre "))
    print(sorted(classmates))

if __name__ == "__main__":
    main()